package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FinalPage {

WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public FinalPage(WebDriver driver) {
		this.driver=driver;
	}
	
	
	//Locator for Placing your order 
	By PlacingYourOrder = By.xpath("/html/body/div[1]/app-root/ui-view/app-root-screen/app-header/div/div[1]/div[1]/div");
	
	//Method to click Place Pickup Order Now Button
	public String getTextFromPage() {
		return driver.findElement(PlacingYourOrder).getText();
	}
	
	
}