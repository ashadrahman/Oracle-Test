package testCases;

import pages.Menu;
import pages.Cart;
import pages.FinalPage;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Tests {
	
	static WebDriver driver = new ChromeDriver();		
	
    @Test
    public void setup(){
		
    System.setProperty("webdriver.chrome.driver", "chromedriver");
	driver.get("https://www.pronto-ny.com/ordering/restaurant/menu?restaurant_uid=ac4a6b17-c1a7-4cee-9d15-8f133");
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
    }
	
	
	/*@Test
    public void selectPizzaTest() {
		Menu menu = new Menu(driver);
		menu.clickPizza();
        
    }*/

}
