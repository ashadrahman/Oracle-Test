package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Menu {

WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public Menu(WebDriver driver) {
		this.driver=driver;
	}
	
		//Locator for Pizza al Salame
		By Pizza = By.xpath("//*[@id=\"mi125769\"]/div/div[1]");
	
		//Method to select Pizza al Salame
		public void clickPizza() {
		driver.findElement(Pizza).click();
		}
	
		//Locator for Large Size
		By LargeMenu = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-addons/div[2]/div[2]/form/div[1]/div/div[2]/label/div/div/div[1]/svg/use");
	
		//Method to select LargeSize
		public void clickLarge() {
		driver.findElement(LargeMenu).click();
		}
		
		//Locator for Extra Toppings - S
		By Corn = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-addons/div[2]/div[2]/form/div[2]/div/div[1]/label/div/div/div[1]/svg/use");
	
		//Locator for Extra Toppings - S
		By Olives = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-addons/div[2]/div[2]/form/div[2]/div/div[2]/label/div/div/div[1]/svg/use");
		
		
		//Method to select 2 Extra Toppings
		public void clickToppings() {
		driver.findElement(Corn).click();
		driver.findElement(Olives).click();			
		}
		
		//Locator for Quantity
		By Quantity = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-addons/div[2]/div[2]/form/div[4]/div/button[2]/svg/use");
		
		//Method to add 2 quantity
		public void clickAddQuantityButton() {
		driver.findElement(Quantity).click();
		}
		
		//Locator for Add to Cart button		
		By AddtoCart = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-addons/div[2]/div[3]/div[2]/div");		
		
		//Method to Click Add to cart button
		public void clickAddtoCartButton() {
			driver.findElement(AddtoCart).click();
		}
		
		
}
