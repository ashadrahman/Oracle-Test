package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Cart {
	
WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public Cart(WebDriver driver) {
		this.driver=driver;
	}

				//Locator for Cart icon
				By CartIcon = By.xpath("/html/body/div[1]/app-root/ui-view/app-root-screen/app-header/div/div[1]/div[4]");

				//Method to click cart icon
				public void clickCartIcon() {
				driver.findElement(CartIcon).click();
				}
		
				//Locator for Contact Info
				By AddDetails = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[1]/div[2]/div/span");	

				//Method to click Add details
				public void clickAddDetails() {
					driver.findElement(AddDetails).click();
				}

				//Locator for First Name field
				By FName = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[1]/div[2]/ui-view/app-profile/div/div/div[2]/form/div[1]/div[1]/input");

				//Method to enter First Name
				public void enterFirstName(String fname) {
				driver.findElement(FName).sendKeys(fname);
				}
		
				//Locator for Last Name field
				By LName = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[1]/div[2]/ui-view/app-profile/div/div/div[2]/form/div[1]/div[2]/input");

				//Method to enter Last Name
				public void enterLastName(String lname) {
					driver.findElement(LName).sendKeys(lname);
				}

				
				//Locator for Email field
				By Email = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[1]/div[2]/ui-view/app-profile/div/div/div[2]/form/div[2]/input");

				//Method to enter Email ID
				public void enterEmail(String email) {
					driver.findElement(Email).sendKeys(email);
				}

				//Locator for Telephone field
				By Phone = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[1]/div[2]/ui-view/app-profile/div/div/div[2]/form/div[3]/input");

				//Method to enter Telephone number
				public void enterPhoneNumber(String phone) {
					driver.findElement(Phone).sendKeys(phone);
				}
				
				//Locator for Save Contact details Button
				By SaveContact = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[1]/div[2]/ui-view/app-profile/div/div/div[4]/div[2]/div/div");

				//Method to click Save button
				public void clickSaveContactButton() {
					driver.findElement(SaveContact).click();
				}
				
				//Locator for Select Order Type button
				By OrderType = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[2]/div[2]/div");

				//Method to click Select order type button
				public void clickSelectOrderTypeButton() {
					driver.findElement(OrderType).click();
				}
				
				//Locator for Select Pickup as Order Type 
				By Pickup = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[2]/div[2]/ui-view/app-type/div/div/div[2]/div[1]/div/svg");
				
				//Method to select Pickup order type
				public void clickPickup() {
					driver.findElement(Pickup).click();
				}
				
				//Locator for Save Order Method Button 
				By SaveOrder = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[2]/div[2]/ui-view/app-type/div/div/div[3]/div/div/div");
				
				//Method to click Save Order Method Button
				public void clickSaveOrderButton() {
					driver.findElement(SaveOrder).click();
				}
				
				
				//Locator for edit Available Time Choice 
				By EditAvailableTimeChoice = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[3]/div[2]/svg");
				
				//Method to click Edit Available Time Choice Button
				public void clickEditAvailableTimeChoiceButton() {
					driver.findElement(EditAvailableTimeChoice).click();
				}
				
				
				//Locator for As soon as possible option 
				By AsSoonAsPossible = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[3]/div[2]/ui-view/app-time/div/div/div[2]/div[1]/div/span");
				
				//Method to check As soon as possible option
				public void checkAsSoonAsPossible() {
					driver.findElement(AsSoonAsPossible).click();
				}
				
				
				//Locator for Save Available Time Choice Button 
				By SaveAvailabeTimeChoice = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[3]/div[2]/ui-view/app-time/div/div/div[4]/div/div/div");
				
				//Method to click Save Available Time Choice Button
				public void clickSaveAvailableTimeChoiceButton() {
					driver.findElement(SaveAvailabeTimeChoice).click();
				}
				
				
				//Locator for Select Payment Method 
				By SelectPaymentMethod = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[4]/div[2]/div/span");
				
				//Method to click Select Payment Method Button
				public void clickSelectPaymentMethodButton() {
					driver.findElement(SelectPaymentMethod).click();
				}
				
				
				//Locator for Cash Payment Method 
				By CashPaymentMethod = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[4]/div[2]/ui-view/app-payment/div/div/div[2]/div/div[1]/div/span");
				
				//Method to Select Cash Payment Method
				public void selectCashPaymentMethod() {
					driver.findElement(CashPaymentMethod).click();
				}
				
				
				//Locator for Save Payment Method Button 
				By SavePaymentMethodButton = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[4]/div[2]/ui-view/app-payment/div/div/div[3]/div[2]/div/div");
				
				//Method to click Save Payment Method Button
				public void clickSavePaymentMethodButton() {
					driver.findElement(SavePaymentMethodButton).click();
				}
				
				
				//Locator for Select a fulfillment option button
				By ClickFulifillmentOptionButton = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[5]/div[2]/div/span");
				
				//Method to click Select a fulfillment option button
				public void clickSelectFulifillmentOptionButton() {
					driver.findElement(ClickFulifillmentOptionButton).click();
				}
				
				
				//Locator for At the restaurant counter option
				By AtRestaurantCounterOption = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[5]/div[2]/ui-view/app-fulfillment-options/div/div/div[2]/div/div/span");
				
				//Method to select At the restaurant counter option
				public void clickAtRestaurantCounterOption() {
					driver.findElement(AtRestaurantCounterOption).click();
				}
				
				
				//Locator for Save Fulfillment Options Button 
				By SaveFulfillmentOptionsButton = By.xpath("//*[@id=\"fb-content\"]/app-restaurant/div/ui-view/app-menu/ui-view/app-checkout/div/div/div[1]/div[1]/div[5]/div[2]/ui-view/app-fulfillment-options/div/div/div[3]/div[2]/div/div");
				
				//Method to click Save Fulfillment Options Button
				public void clickSaveFulfillmentOptionsButton() {
					driver.findElement(SaveFulfillmentOptionsButton).click();
				}
				
				
				//Locator for Place Pickup Order Now Button 
				By PlacePickupOrderNowButton = By.xpath("/html/body/div[1]/app-root/ui-view/app-root-screen/app-footer/div/div/div[1]/div[2]/div/div[3]");
				
				//Method to click Place Pickup Order Now Button
				public void clickPlacePickupOrderNowButton() {
					driver.findElement(PlacePickupOrderNowButton).click();
				}
				
				
				
			


}
